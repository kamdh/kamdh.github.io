#!/usr/bin/python
import sys
import numpy as np
import networkx as nx
from scipy import sparse, io
#from multiprocessing import Pool
#from functools import partial

# constants
toolbar_width = 40

# function defs
def threshmap(f, threshlow, threshhi):
    if (f < threshlow) or (f > threshhi):
        return 0
    elif (f < 0) or (f > 1):
        print "threshmap: uh-oh, f is " + str(f)
        raise NameError('ThreshMapRangeError')
    else: 
        return 1

# submatrix
# utility function, retains the submatrix defined by some
# set of indices
def submatrix(A, indices):
    if sparse.issparse(A):
        indices = np.squeeze(np.array(indices))
    tmp = A[:, indices]
    tmp = tmp[indices, :]
    return( tmp )

def step_dynamics(x, A, degrees, alpha, thresh):    
    # initialize result
    y = x.copy()
    N = len(x)
    # pick nodes to update
    # degree 0 nodes do not update
    if alpha != 1:
        # nodes update with probability alpha
        nodemask =  (np.random.random_sample(N) < alpha) \
                              & (degrees > 0)
    else:
        nodemask = degrees > 0
    nodemask = np.squeeze(np.array(nodemask))
    nodes = np.where(nodemask) # returns 1-tuple
    nodes = np.squeeze(np.array(nodes[0]))  # extract array from tuple
    # project matrices and vectors into updating subspace
    Np = len(nodes)
    Ap = submatrix(A, nodes)
    degp = degrees[nodes]
    xp = x[nodes].reshape(Np,1) # shape (len(nodes), 1)
    threshp = thresh[nodes,:]
    # compute update
    # next line avoids numerical problems, reshape allows elt-wise divide
    frac_on = (Ap * xp) / degp.reshape(Np,1)
    #v_threshmap = np.vectorize(threshmap)
    #yp = v_threshmap(frac_on, threshp[:,0], threshp[:,1])
    yp = np.array(map(threshmap, frac_on, threshp[:,0], threshp[:,1]))
    yp = yp.astype('float') # cast bool to float
    y[nodemask] = yp
    return(y)

def main(argv=None):
    # parse arguments
    if argv is None:
        argv = sys.argv
    z = float(argv[1])
    alpha = float(argv[2])
    N = int(argv[3])
    T = int(argv[4])
    SAVET = int(argv[5])
    if (SAVET > T):
        print "SAVET > T"
        raise NameError('SaveTimeError')
    sparseflag = argv[6]
    if sparseflag == 'sparse':
        sparseflag = True
    elif sparseflag == 'full':
        sparseflag = False
    else:
        print "uh-oh, sparse flag given as " + sparseflag + \
            ", use 'sparse' or 'full'"
        raise NameError('SparseFlagError')
    fn = argv[7]
    print "running random mixing chaotic contagion for"
    print "z\t=\t" + str(z)
    print "alpha\t=\t" + str(alpha)
    print "N\t=\t" + str(N)
    print "T\t=\t" + str(T)
    print "SAVET\t=\t" + str(SAVET)
    print "state matrix sparse? %s\n" % str(sparseflag)

    # initialization
    print "initializing ..."
    if sparseflag:
        state = sparse.lil_matrix( (SAVET,N), dtype='int8' )
        #state = sparse.csc_matrix( (SAVET,N), dtype='int8' )
    else:
        state = np.zeros( (SAVET,N), dtype='int8')
    rho = np.zeros( T, dtype='float' )
    rhoE = np.zeros( T, dtype='float' )
    G = nx.fast_gnp_random_graph(N, float(z)/N)
    if sparseflag:
        #A = sparse.csc_matrix( nx.to_numpy_matrix(G) )
        A = sparse.lil_matrix( nx.to_numpy_matrix(G) )
        degrees = np.squeeze(A.sum(axis=0))
        degrees = degrees.reshape((N,1))
    else: 
        A = nx.to_numpy_matrix(G)
        degrees = np.squeeze(A.sum(axis=0))
        degrees = degrees.reshape((N,1))
    thresh = np.zeros( (N, 2), dtype='float')
    thresh[:,0] = np.random.random_sample(N)*(0.5)
    thresh[:,1] = np.random.random_sample(N)*(0.5) + 0.5
    #degrees = np.squeeze( A.sum(axis=0) )
    #degrees = np.squeeze(np.array(np.sum(A, axis=0)))
    nonzerodegnodes = np.where( degrees > 0 )[0]

    # random initial seed
    t = 0
    x = np.zeros(N, dtype='float')
    x[ np.random.randint(0,N) ] = 1 
    rho[t] = np.sum(x, dtype='float')/N
    rhoE[t] = np.sum(np.dot(x, degrees), dtype='float')/degrees.sum()
    ic = x

    # simulation stage
    print "simulating ..."
    # setup simple toolbar
    # from http://stackoverflow.com/questions/3160699/python-progress-bar
    global toolbar_width
    if toolbar_width > T:
        toolbar_width = T
    sys.stdout.write("[%s]" % (" " * toolbar_width ))
    sys.stdout.flush()
    # return to start of line, after '['
    sys.stdout.write("\b" * (toolbar_width+1))

    # start of control loops
    
    # iterate through transient (T-SAVET)
    while (t < ( T - (SAVET+1) ) ) and np.any( x[nonzerodegnodes] != 0 ):
        # step dynamics
        x = step_dynamics(x, A, degrees, alpha, thresh)
        t = t + 1
        rho[t] = np.sum(x, dtype='float')/N
        rhoE[t] = np.sum(np.dot(x, degrees), dtype='float')/degrees.sum()
        # toolbar action
        if ( t % (T/toolbar_width) )==0 :
            sys.stdout.write('#')
            sys.stdout.flush()
    t2 = 0
    # now we save state
    while ( t < ( T - 1 ) ) and np.any( x[nonzerodegnodes] != 0 ):
        # step dynamics
        x = step_dynamics(x, A, degrees, alpha, thresh)
        t = t + 1
        rho[t] = np.sum(x, dtype='float')/N
        rhoE[t] = np.sum(np.dot(x, degrees), dtype='float')/degrees.sum()
        # print "filling state with x, shape " + str(x.shape) + \
        #     ", " + str(x.sum()) + " on nodes," + \
        #     " at time " + str(t)
        state[t2,:] = x
        t2 = t2 + 1
        # toolbar action
        if ( t % (T/toolbar_width) )==0 :
            sys.stdout.write('#')
            sys.stdout.flush()
    print "\nnormal integration stopped at t = " + str(t)
    # fill in state in case of early termination
    if (t < (T - 1)) and ( rho[t] != 0 ) and \
            np.all( x[nonzerodegid:(N-1)] == 0 ):
        # early termination but active, degree-0 nodes
        print "filling in frozen state"
        while (t < (T - 1)):
            t = t + 1
            rho[t] = rho[t-1]
            rhoE[t] = rhoE[t-1]
        while ( t2 < SAVET ):
            state[t2,:] = x
            t2 = t2 + 1
    print "done!"
    
    #  cleanup
    state = state.astype('float')
    if sparseflag:
        state = state.tocsc()
        A = A.tocsc()
    
    io.savemat(fn, {'state': state, 'rho': rho, \
                        'deg': degrees, 'rhoEdges': rhoE, \
                        'A':sparse.csc_matrix(A), \
                        'alpha':alpha, 'z':z, 'ic':ic, 'thresh':thresh}, \
                   do_compression=True, format='5', oned_as='column')

# run the main stuff
if __name__ == "__main__":
    main()
