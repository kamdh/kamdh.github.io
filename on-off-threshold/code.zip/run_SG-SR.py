#!/usr/bin/python
import sys
import numpy as np
from scipy import sparse, io
from multiprocessing import Pool
from functools import partial

# constants
toolbar_width = 40
chunknum = 8 # something like 2x nprocs

# function defs
def updatenode(node, x, degrees, cumdegpr):
    # this degree
    deg = degrees[node]
    # pick friends \propto degree
    c = np.random.random_sample(deg)
    neighbors = np.searchsorted(cumdegpr, c)
    # calculate the fraction active
    frac_on = np.sum( x[neighbors] ) / deg
    #frac_on = float( np.take(x, neighbors).sum() ) / deg
    prob_on = tentmap(frac_on)
    # flip final coin
    if (np.random.random_sample() < prob_on):
        return(1)
    else:
        return(0)

def tentmap(f):
    if (f <= 0.5) and (f >= 0):
        return 2*f
    elif (f > 0.5) and (f <= 1):
        return 2-2*f
    else:
        print "tentmap(f): uh-oh, f is " + str(f)
        raise NameError('TentMapRangeError')

def step_dynamics(x, degrees, cumdegpr, alpha):    
    # initialize result
    y = x.copy()
    N = len(x)
    # pick guys to update
    if alpha != 1:
        nodemask =  (np.random.random_sample(N) < alpha) \
                              & (degrees > 0)
    else:
        nodemask = degrees > 0
    nodes = np.where(nodemask)
    nodes = nodes[0]
    # partialize function
    p_updatenode = partial(updatenode, x=x, \
                               degrees=degrees, cumdegpr=cumdegpr)
    # update them in parallel
    chunksize = np.round(N/chunknum)
    #chunksize = N
    po = Pool()
    tmp = po.map(p_updatenode, nodes, chunksize)
    po.close()
    po.join()
    #tmp = map(p_updatenode, nodes)
    y[nodemask] = tmp
    return(y)

def main(argv=None):
    # read in arguments
    if argv is None:
        argv = sys.argv

    z = float(argv[1])
    alpha = float(argv[2])
    N = int(argv[3])
    T = int(argv[4])
    SAVET = int(argv[5])
    if (SAVET > T):
        print "SAVET > T"
        raise NameError('SaveTimeError')
    sparseflag = argv[6]
    if sparseflag == 'sparse':
        sparseflag = True
    elif sparseflag == 'full':
        sparseflag = False
    else:
        print "uh-oh, sparse flag given as " + sparseflag + \
            ", use 'sparse' or 'full'"
        raise NameError('SparseFlagError')
    fn = argv[7]
    print "running random mixing chaotic contagion for"
    print "z\t=\t" + str(z)
    print "alpha\t=\t" + str(alpha)
    print "N\t=\t" + str(N)
    print "T\t=\t" + str(T)
    print "SAVET\t=\t" + str(SAVET)
    print "state matrix sparse? %s\n" % str(sparseflag)
    ## initialization
    print "initializing ..."
    if sparseflag:
        state = sparse.lil_matrix( (SAVET,N), dtype='int8' )
    else:
        state = np.zeros( (SAVET,N), dtype='int8')
    rho = np.zeros( T, dtype='float' )
    rhoE = np.zeros( T, dtype='float' )
    degrees = np.random.poisson(z, size=N)
    degrees.sort()
    nonzerodegid = np.sum(degrees == 0)
    cumdegpr = np.cumsum(degrees, dtype='float')/degrees.sum()
    # random initial seed
    t = 0
    x = np.zeros(N, dtype='float')
    x[ np.random.randint(0,N) ] = 1 
    rho[t] = np.sum(x, dtype='float')/N
    rhoE[t] = np.sum(np.dot(x, degrees), dtype='float')/degrees.sum()

    print "simulating ..."
    # setup simple toolbar
    # from http://stackoverflow.com/questions/3160699/python-progress-bar
    global toolbar_width
    if toolbar_width > T:
        toolbar_width = T
    sys.stdout.write("[%s]" % (" " * toolbar_width ))
    sys.stdout.flush()
    # return to start of line, after '['
    sys.stdout.write("\b" * (toolbar_width+1))
    
    # iterate through transient
    while (t < ( T - (SAVET+1) ) ) and np.any( x[nonzerodegid:(N-1)] != 0 ):
        # step dynamics
        x = step_dynamics(x, degrees, cumdegpr, alpha)
        t = t + 1
        rho[t] = np.sum(x, dtype='float')/N
        rhoE[t] = np.sum(np.dot(x, degrees), dtype='float')/degrees.sum()
        # toolbar action
        if ( t % (T/toolbar_width) )==0 :
            sys.stdout.write('#')
            sys.stdout.flush()
    t2 = 0
    # now we save state
    while ( t < ( T - 1 ) ) and np.any( x[nonzerodegid:(N-1)] != 0 ):
        # step dynamics
        x = step_dynamics(x, degrees, cumdegpr, alpha)
        t = t + 1
        rho[t] = np.sum(x, dtype='float')/N
        rhoE[t] = np.sum(np.dot(x, degrees), dtype='float')/degrees.sum()
        state[t2,:] = x
        t2 = t2 + 1
        # toolbar action
        if ( t % (T/toolbar_width) )==0 :
            sys.stdout.write('#')
            sys.stdout.flush()
    print "\nnormal integration stopped at t = " + str(t)
    # fill in state in case of early termination
    if (t < (T - 1)) and ( rho[t] != 0 ) and \
            np.all( x[nonzerodegid:(N-1)] == 0 ):
        # early termination but active, degree-0 nodes
        print "filling in frozen state"
        while (t < (T - 1)):
            t = t + 1
            rho[t] = rho[t-1]
            rhoE[t] = rhoE[t-1]
        while ( t2 < SAVET ):
            state[t2,:] = x
            t2 = t2 + 1
    print "done!"
    
    #  cleanup
    state = state.astype('float')
    if sparseflag:
        state = state.tocsc()
    
    io.savemat(fn, {'state': state, 'rho': rho, \
                        'deg': degrees, 'rhoEdges': rhoE}, \
                   do_compression=True, format='5', oned_as='column')

# run the main stuff
if __name__ == "__main__":
    main()
