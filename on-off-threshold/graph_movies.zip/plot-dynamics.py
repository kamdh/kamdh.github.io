#!/usr/bin/python

#
# plot-dynamics.py
#
# by Kameron Decker Harris, 2012
#
# usage:
#   ./plot_dynamics.py FILENAME OUTPUT_DIR PDF_FLAG T_F
#
# FILENAME: .mat file containing simulation output
# OUTPUT_DIR: directory for resulting images
# PDF_FLAG: 0 = output multiple .png files, 1 = output one .pdf
# T_F: sets the final time step
#

import sys
import numpy as np
import networkx as nx
from scipy import sparse, io
import matplotlib.pyplot as plt

def main(argv=None):
    # read in arguments
    if argv is None:
        argv = sys.argv
    fn = argv[1]
    outdir = argv[2]
    multiflag = int(argv[3])
    maxT = int(argv[4])
    print "loading data"
    x = io.loadmat(fn)
    # x is a dict containing x['rho'], x['state'], x['A'], etc
    # load relevant data
    rho = x['rho']
    G = nx.Graph(x['A'])
    nodestates = x['state']   # rows are states
    T = nodestates.shape[0]

    # plotting
    print "generating layout"
    layoutscale = 10 # places nodes in [0, scale]^2 box
    if (G.number_of_nodes > 100) :
        itnum = 20
    else:
        itnum = 50
    layoutpos=nx.spring_layout(G, iterations=itnum, scale=layoutscale)
    #layoutpos = nx.spectral_layout(G)
    if 'thresh' in x:
        titlestr = r'deterministic dynamics for $N = %d $, $z = %.1f $, $\alpha = %.1f $' % ( x['A'].shape[0], x['z'], float(x['alpha']) )
    else:
        titlestr = r'stochastic dynamics for $N = %d $, $z = %.1f $, $\alpha = %.1f $' % ( x['A'].shape[0], x['z'], float(x['alpha']) )
    
    print titlestr
    print "plotting times"
    if multiflag:
        from matplotlib.backends.backend_pdf import PdfPages
        pp = PdfPages(outdir + "/multipage.pdf")
    for t in range(maxT):
        print str(t)
        # params = { 'axes.labelsize': 10,
        #            'text.fontsize': 10,
        #            'text.usetex': True }
        # rcParams.update(params)
        fig = plt.figure(figsize=(12, 12))
        plt.axis('off')
        plt.title(titlestr, fontsize=24)
        ax = plt.axes([0, .2, .7, .7], frameon=False)
        ax.axes.get_xaxis().set_visible(False) #disable axis visibility
        ax.axes.get_yaxis().set_visible(False)
        nx.draw_networkx_nodes(G, layoutpos, with_labels=False, \
                                   alpha=0.7, \
                                   node_color=nodestates[t,:], \
                                   cmap=plt.cm.Blues)
        nx.draw_networkx_edges(G, layoutpos, alpha=0.5)
        # nx.draw(G, layoutpos, with_labels=False, \
            #             node_color=nodestates[t,:], cmap=plt.cm.Blues)
        # time counter text
        plt.text(5, -2, 't = %d' % t, fontsize=20)

        # draw inset density
        inax = plt.axes([.72, .1, .2, .2])
        plt.setp(inax, xlim=(1, (maxT) ), ylim=(0, 1) )
        plt.plot( range(1,t+1), rho[0:t], '.' )
        if maxT > 200:
            xtickstep = 100
        else:
            xtickstep = 50
        plt.xticks(range(0, maxT+1, xtickstep))
        plt.ylabel('active fraction', fontsize=18)
        #plt.ylabel(r'$\rho$', fontsize=20)
        plt.xlabel('t', fontsize=18)

        # draw zoomed inset density
        # useful for post-collapse
        # inax2 = plt.axes([.72, .31, .2, .2])
        # inax2.axes.get_xaxis().set_visible(False)
        # plt.plot( range(1,t+1), rho[0:t], '.' )
        # plt.ylabel('active fraction', fontsize=18)
        # #plt.ylabel(r'$\rho$', fontsize=20)
        # #plt.xlabel('t', fontsize=18)
        # yDelta = (rho.max()-rho.min())*.15
        # ylimits = ( rho.min()-yDelta, rho.max()+yDelta )
        # plt.setp(inax2, xlim=(1, (maxT) ), ylim=ylimits )
        
        if multiflag:
            pp.savefig()
        else:
            file_t = outdir + "/" + str(t) + ".png"
            plt.savefig(file_t)
            plt.close()
    if multiflag:
        pp.close()

    print "done!"

# run the main stuff
if __name__ == "__main__":
    main()
