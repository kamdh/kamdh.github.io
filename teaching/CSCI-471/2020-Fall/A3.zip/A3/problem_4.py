import numpy as np
import matplotlib.pyplot as plt

X = np.loadtxt("Churchland_data.txt")
n, d = X.shape
# In this dataset, n is the number of neurons and d is the number of time points

def PCA(X):
    '''
    Compute the PCA of X = U S V^T

    Parameters:
    X (np.ndarray, ndim=2): n x d data matrix

    Returns:
    U (np.ndarray, ndim=2): n x n left singular vectors
    S (np.ndarray, ndim=1): p vector of singular values
    V (np.ndarray, ndim=2): p x p array of right singular vectors
    '''
    # step 1: subtract column means
    # step 2: take svd
    #return U, S, V

def frac_var_explained(s):
    '''
    Compute the fraction of variance explained

    Parameters:
    s (np.ndarray, ndim=1): p vector of singular values

    Returns:
    f (np.ndarray, ndim=1): p vector of cumulative variance explained
    '''
    

