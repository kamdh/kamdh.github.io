import numpy as np
from pandas import read_csv

# Pandas is a useful library for working with data
data = read_csv("prostate.data", sep='\t')

# We will convert it into a np.ndarray
# we will predict lpsa (log prostate specific antigen)
target = 'lpsa'
# based on the following features
features = ['lcavol', 'lweight', 'age', 'lbph',
            'svi', 'lcp', 'gleason', 'pgg45']
# split data into training/test sets based on the train flag
is_train = data.train == 'T'
X, y = data[features].values, data[target].values
X_train, y_train = X[is_train], y[is_train]
X_test, y_test = X[~is_train], y[~is_train]

# 5.1 estimate the means and standard deviations of the features using just the training data
print(mean_vec)
print(std_vec)

# 5.2 standardize X_train and X_test and form matrices X_train_std, X_test_std
# your code here
# make sure the following lines are included afterwards to save your results
np.savetxt("X_train_std.txt", X_train_std)
np.savetxt("X_test_std.txt", X_test_std)
# Hint: check these
np.mean(X_train, axis=0)
np.std(X_train, axis=0)
np.mean(X_test, axis=0)
np.std(X_test, axis=0)


# 5.3
def ridge(X, alpha):
    '''
    Ridge regression function
    
    Parameters:
    X (np.ndarray, ndim=2): n x d data matrix of covariates (without augmenting using 1s)
    alpha (float): a positive float, the ridge parameter

    Returns:
    beta (np.ndarray, ndim=1): (1 + d) vector, first coefficient is intercept
    '''
    # form the augmented matrix X with a first column of 1s
    # form the D matrix
    # solve the equations
    assert alpha > 0, 'alpha should be greater than zero'
    pass

# 5.4
