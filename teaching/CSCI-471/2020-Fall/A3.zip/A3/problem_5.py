import numpy as np
from pandas import read_csv

# Pandas is a useful library for working with data
data = pandas.read_csv("prostate.data", sep='\t')

# We will convert it into a np.ndarray
X_train = np.array(data[data['train'] == 'T'].iloc[:, :9]) # first 9 columns
y_train = np.array(data[data['train'] == 'T'].iloc[:, 9]) # 10th column
X_test = np.array(data[data['train'] == 'F'].iloc[:, :9]) # first 9 columns
y_test = np.array(data[data['train'] == 'F'].iloc[:, 9]) # 10th column


# 5.1 estimate the means and standard deviations of the features using just the training data
print(mean_vec)
print(std_vec)

# 5.2 standardize X_train and X_test and form matrices X_train_std, X_test_std
# your code here
# make sure the following lines are included afterwards to save your results
np.savetxt("X_train_std.txt", X_train_std)
np.savetxt("X_test_std.txt", X_test_std)
# Hint: check these
np.mean(X_train, axis=0)
np.std(X_train, axis=0)
np.mean(X_test, axis=0)
np.std(X_test, axis=0)


# 5.3
def ridge(X, alpha):
    '''
    Ridge regression function
    
    Parameters:
    X (np.ndarray, ndim=2): n x d data matrix of covariates (without augmenting using 1s)
    alpha (float): a positive float, the ridge parameter

    Returns:
    beta (np.ndarray, ndim=1): (1 + d) vector, first coefficient is intercept
    '''
    # form the augmented matrix X with a first column of 1s
    # form the D matrix
    # solve the equations
    assert alpha > 0, 'alpha should be greater than zero'
    pass

# 5.4
