import numpy as np

def lasso_solver(X, y, beta_init, penalty, tol):
    '''
    Solve the Lasso equations using coordinate descent.

    Parameters:
    X (np.ndarray, ndim=2): n x d data matrix without extra column of 1s
    y (np.ndarray, ndim=1): n x 1 label vector
    beta_init (np.ndarray, ndim=1): (d + 1) x 1 initial guess
    penalty (float): Lasso penalty >= 0, lambda in our math
    tol (float): convergence tolerance >= 0, delta in our math 

    Returns:
    beta (np.ndarray, ndim=1): (d + 1) x 1 solution
    '''
    assert penalty >= 0, "penalty should be >= 0"
    assert tol >= 0, "tolerance should be >= 0"
    n, d = X.shape
    beta = beta_init
    converged = False
    while not converged:
        beta_old = beta
        # your update steps here
        # check for convergence between beta and beta_old
        if converged:
            break
    
    return beta
