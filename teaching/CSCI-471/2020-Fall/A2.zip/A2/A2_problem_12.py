import numpy as np

# load data from http://lib.stat.cmu.edu/datasets/boston
X = np.readtxt("housing_X.txt")
y = np.readtxt("housing_y.txt")

# your solution here
