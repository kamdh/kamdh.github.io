import numpy as np

def solve_system_ALG(n):
    '''
    Solve a random linear system Ax = b, where A and b are random.

    Parameters: 
    n (int): size of linear system n x n

    Returns:
    A, b, x (np.ndarray): system matrix, rhs, solution
    '''

    A = np.random.randn(n, n)
    b = np.random.randn(n)

    # Your code here to solve A x = b

    return (A, b, x)

