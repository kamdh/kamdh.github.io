import numpy as np

def true_fun(X):
    '''
    The true target function
    '''
    return np.cos(1.5 * np.pi * X[:,0]) - 0.3 * np.sin(2 * np.pi * X[:,1])

def poly_features(X, p):
    '''
    Compute the polynomial features of degree p

    Parameters:
    X (np.ndarray, ndim=2): n x d data matrix
    p (int): degree of polynomial

    Returns:
    F (np.ndarray, ndim=2): n x f feature matrix    
    '''
    # copy your solution from problem 10 here

    return F

def test_error(true_fun, prediction_fun, n_test):
    '''
    Compute the average testing squared error
    '''
    # your solution here

    return mean_squared_error

np.random.seed(0) # do not change this

n_samples = 40

X = np.random.rand(n_samples, 2)
y = true_fun(X) + np.random.randn(n_samples) * 0.2

